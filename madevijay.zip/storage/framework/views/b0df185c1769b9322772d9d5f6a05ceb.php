<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Vue App</title>
    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app"></div>  <!-- This is where Vue will be mounted -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\example-vijay\resources\views/home.blade.php ENDPATH**/ ?>